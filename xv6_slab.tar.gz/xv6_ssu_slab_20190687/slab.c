#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "spinlock.h"
#include "slab.h"

struct {
    struct spinlock lock;
    struct slab slab[NSLAB];
} stable;

// Initialize the slab allocator
void slabinit() {
    initlock(&stable.lock, "slab");
    for (int i = 0; i < NSLAB; i++) {
        int slabsize = 1 << (i + 4);
        int num_obj_per_page = PGSIZE / slabsize;
        stable.slab[i].size = slabsize;
        stable.slab[i].num_objects_per_page = num_obj_per_page;
        stable.slab[i].num_pages = 0;
        stable.slab[i].num_free_objects = 0;
        stable.slab[i].num_used_objects = 0;
        stable.slab[i].bitmap = kalloc();
        memset(stable.slab[i].bitmap, 0, PGSIZE);
        for (int j = 0; j < MAX_PAGES_PER_SLAB; j++) {
            stable.slab[i].page[j] = 0;
        }
    }
}

// Allocate memory from the slab allocator
char *kmalloc(int size) {
    if (size <= 0 || size > 2048) {
        return 0;
    }

    acquire(&stable.lock);

    // Find the appropriate slab class
    int slab_idx = -1;
    for (int i = 0; i < NSLAB; i++) {
        if (stable.slab[i].size >= size) {
            slab_idx = i;
            break;
        }
    }

    if (slab_idx == -1) {
        release(&stable.lock);
        return 0;
    }

    struct slab *sl = &stable.slab[slab_idx];

    // Search for a free object
    int obj_idx = -1;
    for (int i = 0; i < (sl->num_pages * sl->num_objects_per_page); i++) {
        int byte_idx = i / 8;
        int bit_idx = i % 8;
        if (!(sl->bitmap[byte_idx] & (1 << bit_idx))) {
            obj_idx = i;
            sl->bitmap[byte_idx] |= (1 << bit_idx);
            break;
        }
    }

    // If no free object is found, allocate a new page
    if (obj_idx == -1) {
        if (sl->num_pages >= MAX_PAGES_PER_SLAB) {
            release(&stable.lock);
            return 0;
        }
        sl->page[sl->num_pages] = kalloc();
        memset(sl->page[sl->num_pages], 0, PGSIZE);
        sl->num_pages++;
        obj_idx = (sl->num_pages - 1) * sl->num_objects_per_page;
        sl->bitmap[obj_idx / 8] |= (1 << (obj_idx % 8));
        sl->num_free_objects += sl->num_objects_per_page;
    }

    sl->num_free_objects--;
    sl->num_used_objects++;

    char *addr = sl->page[obj_idx / sl->num_objects_per_page] + (obj_idx % sl->num_objects_per_page) * sl->size;
    release(&stable.lock);
    return addr;
}

// Free memory back to the slab allocator
void kmfree(char *addr, int size) {
    if (size <= 0 || size > 2048 || addr == 0) {
        return;
    }

    acquire(&stable.lock);

    // Find the appropriate slab class
    int slab_idx = -1;
    for (int i = 0; i < NSLAB; i++) {
        if (stable.slab[i].size >= size) {
            slab_idx = i;
            break;
        }
    }

    if (slab_idx == -1) {
        release(&stable.lock);
        return;
    }

    struct slab *sl = &stable.slab[slab_idx];

    // Find the object index
    int obj_idx = -1;
    for (int i = 0; i < (sl->num_pages * sl->num_objects_per_page); i++) {
        char *free_addr = sl->page[i / sl->num_objects_per_page] + (i % sl->num_objects_per_page) * sl->size;
        if (free_addr == addr) {
            obj_idx = i;
            break;
        }
    }

    if (obj_idx == -1) {
        release(&stable.lock);
        return; // Object not found (already freed)
    }

    int byte_idx = obj_idx / 8;
    int bit_idx = obj_idx % 8;
    if (!(sl->bitmap[byte_idx] & (1 << bit_idx))) {
        release(&stable.lock);
        return; // Object already freed
    }

    sl->bitmap[byte_idx] &= ~(1 << bit_idx);
    sl->num_free_objects++;
    sl->num_used_objects--;

    int page_idx = obj_idx / sl->num_objects_per_page;
    int page_start_idx = page_idx * sl->num_objects_per_page;
    int page_end_idx = page_start_idx + sl->num_objects_per_page - 1;

    int is_page_empty = 1;
    for (int i = page_start_idx; i <= page_end_idx; i++) {
        int byte_idx = i / 8;
        int bit_idx = i % 8;
        if (sl->bitmap[byte_idx] & (1 << bit_idx)) {
            is_page_empty = 0;
            break;
        }
    }

    if (is_page_empty) {
        kfree(sl->page[page_idx]);
        for (int i = page_idx; i < sl->num_pages - 1; i++) {
            sl->page[i] = sl->page[i + 1];
        }
        sl->num_pages--;
        sl->num_free_objects -= sl->num_objects_per_page;

        // Update bitmap to shift pages
        int shift_start_idx = page_idx * sl->num_objects_per_page;
        int shift_end_idx = sl->num_pages * sl->num_objects_per_page;
        for (int i = shift_start_idx; i < shift_end_idx; i++) {
            int src_byte_idx = (i + sl->num_objects_per_page) / 8;
            int src_bit_idx = (i + sl->num_objects_per_page) % 8;
            if (sl->bitmap[src_byte_idx] & (1 << src_bit_idx)) {
                sl->bitmap[i / 8] |= (1 << (i % 8));
            } else {
                sl->bitmap[i / 8] &= ~(1 << (i % 8));
            }
        }

        // Clear the remaining bits from the last page
        for (int i = shift_end_idx; i < shift_end_idx + sl->num_objects_per_page; i++) {
            sl->bitmap[i / 8] &= ~(1 << (i % 8));
        }
    }

    release(&stable.lock);
}

void slabdump() {
    cprintf("__slabdump__\n");
    struct slab *s;
    cprintf("size\tnum_pages\tused_objects\tfree_objects\n");
    for (s = stable.slab; s < &stable.slab[NSLAB]; s++) {
        cprintf("%d\t%d\t\t%d\t\t%d\n", s->size, s->num_pages, s->num_used_objects, s->num_free_objects);
    }
}

int numobj_slab(int slabid) {
    return stable.slab[slabid].num_used_objects;
}

int numpage_slab(int slabid) {
    return stable.slab[slabid].num_pages;
}